# Simplified operating-model guides

Three examples to adapt when using agents to build a regression test suite:

1. [Delivery workflow](01-delivery-workflow.md): one task from selection through review, approved delivery and recorded acceptance.
2. [Test design and evidence](02-test-design-and-evidence.md): what the test should check, how it handles failure and what evidence to review.
3. [Agent roles and context](03-agent-roles-and-context.md): coordinator and implementation responsibilities, source loading and reusable learning.

These guides accompany **Simplifying the agents behind my regression suite**, part of the Agentic QA series. They are simplified examples, not a copy of an installed configuration. The operating model uses shared delivery instructions, testing instructions and two separate agent profiles, plus supporting records. The third guide groups both roles for readability.

## Before adapting them

Provide your own task template, agent definitions, tool permissions, runner and authentication setup, test data, cleanup implementation, reporting and verification commands. Specify the environments and actions the agents may use. Apply testing instructions to the intended files through your tool's supported configuration.

The example command `npm run verify` is project-defined. It must invoke real checks; it is not a standard Playwright command. In the described workflow, local verification covers code and selected documentation consistency checks. No scripts, hooks or reporting framework are included in these guides.

The five-run criterion applies to live business acceptance: five passing staging runs with retries disabled, followed by human evidence review. If required staging data is unavailable, code may be merged after the agreed checks and approvals while business acceptance remains pending.

This is one workflow's acceptance criterion, not a universal quality standard. Passing runs do not establish complete coverage or maintainability. Written approval rules depend on agent compliance unless permissions or repository protections enforce them. These guides do not install a CI merge gate.

## Records the workflow uses

- **Task issue and pull request:** scope, decisions, current work and unresolved acceptance.
- **Learning Handoff:** the task-specific account of what changed, what was checked and what remains open.
- **Agent learning files:** short, reviewed lessons useful to later tasks.
- **UI map:** confirmed page controls, relevant states and reusable interaction knowledge.
- **Test catalog:** scenario steps and expected results, linked to the corresponding tests.
- **Runner guidance:** approved commands, required data and known limitations.
